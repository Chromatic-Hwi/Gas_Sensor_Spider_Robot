#!/bin/sh

# Do not run this again, the files are now configured

#docker run --rm telegraf telegraf config > telegraf.conf
#docker run --rm influxdb influxd config > influxdb/influxdb.conf
