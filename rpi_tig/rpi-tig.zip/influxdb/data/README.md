This is where the influxDB database is located
