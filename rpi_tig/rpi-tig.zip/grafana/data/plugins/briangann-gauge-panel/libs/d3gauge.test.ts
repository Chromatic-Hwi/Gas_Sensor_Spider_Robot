describe('d3gauge test', () => {
  it('d3gauge should be defined', () => {
    expect(true).toBeTruthy();
  });
});
