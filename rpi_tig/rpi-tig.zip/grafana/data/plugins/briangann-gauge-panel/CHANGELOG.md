# Change Log

All changes noted here.

## v0.0.9 - 2021-04-21

- Add option to display needle arrow
- Update packages

## v0.0.8 - 2020-10-26

- Signed Plugin!
- Updated build process

## v0.0.7 - 2020-04-18

- Fixes
  - Update to typescript and using standardized build process.
  - Simplified value display

## v0.0.1

- Initial commit
