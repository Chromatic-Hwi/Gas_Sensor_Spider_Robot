This is where the Grafana data files go
